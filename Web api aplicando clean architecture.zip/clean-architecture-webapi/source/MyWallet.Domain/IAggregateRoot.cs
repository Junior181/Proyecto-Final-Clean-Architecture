namespace MyWallet.Domain {
    internal interface IAggregateRoot : IEntity { }
}